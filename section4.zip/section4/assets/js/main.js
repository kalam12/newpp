$(document).ready(function($){
	"use strict";

	// WOW Js Active
	new WOW().init();

	// ---- Active
    $(".homepage-slide").owlCarousel({
		items:1,
		autoplay:false,
		dots:true, 
		margin:30,
		nav:true,
		navText:["<i class='fa fa-long-arrow-left'></i>","<i class='fa fa-long-arrow-right'></i>"]
		
		
	});
	
	 $(".team-list").owlCarousel({
		items:3,
		autoplay:false,
		dots:true, 
		margin:30,
	});
$(".testimonail-list").owlCarousel({
		items:3,
		autoplay:false,
		dots:true, 
		margin:30,
	});
	
$(".logo-carsal").owlCarousel({
		items:3,
		autoplay:false,
		dots:false, 
		margin:30,
	});
    // Owl Next Privew Change
    //$( ".owl-prev").html('<i class="fa screenshort-arow fa-chevron-left"></i>');
    //$( ".owl-next").html('<i class="fa screenshort-arow fa-chevron-right"></i>');
	
	
$('#webdesing-skril-bar').circleProgress({
    value: 0.9,
    size: 270,
    fill: {
      gradient: ["red", "orange"]
    }
  }).on('circle-animation-progress', function(event, progress) {
    $(this).find('.skrill-count-number').html(Math.round(90 * progress) + '<i>%</i>');
  });
	
	$('#graphi-skril-bar').circleProgress({
    value: 0.95,
    size: 270,
    fill: {
      gradient: ["red", "orange"]
    }
  }).on('circle-animation-progress', function(event, progress) {
    $(this).find('.skrill-count-number').html(Math.round(95 * progress) + '<i>%</i>');
  });
	
	$('#digital-skril-bar').circleProgress({
    value: 0.84,
    size: 270,
    fill: {
      gradient: ["red", "orange"]
    }
  }).on('circle-animation-progress', function(event, progress) {
    $(this).find('.skrill-count-number').html(Math.round(84 * progress) + '<i>%</i>');
  });
	
	
	
	$(".play-icon").magnificPopup({
		type:'video',
	});

}(jQuery));